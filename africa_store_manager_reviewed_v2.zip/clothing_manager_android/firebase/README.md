# Firebase deployment — Africa Store Manager

Firebase project: `africa-store-manager`

From this directory (the directory containing `firebase.json` and `.firebaserc`):

```bash
firebase login
cd functions
npm install
npm run build
cd ..
firebase deploy --only firestore:rules,functions
```

The Firestore rules are in `firestore.rules`. The callable functions are in `functions/`. Do not grant sellers direct write access to sales or stock to bypass `syncOfflineSale`; the callable performs the sale and stock deduction in one server transaction.

The first login on a device requires internet. Once a user has signed in and the branch stock has been cached, queued sales are stored on that device and retried when connectivity returns. A queued sale is not a centrally approved invoice until the callable confirms it.
