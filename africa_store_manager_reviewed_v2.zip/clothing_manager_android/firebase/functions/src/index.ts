import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { onCall, HttpsError } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();

async function requireManager(uid: string) {
  const snap = await db.doc(`users/${uid}`).get();
  const u = snap.data();
  if (!u || u.active !== true || !['manager', 'admin'].includes(u.role)) {
    throw new HttpsError('permission-denied', 'Manager access required');
  }
  return u;
}

function cleanText(value: unknown, field: string, max = 120): string {
  if (typeof value !== 'string' || value.trim().length === 0 || value.trim().length > max) {
    throw new HttpsError('invalid-argument', `${field} is required (max ${max} characters)`);
  }
  return value.trim();
}

function cleanList(value: unknown, field: string): string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 40 || value.some(v => typeof v !== 'string' || v.trim().length === 0 || v.trim().length > 40)) {
    throw new HttpsError('invalid-argument', `${field} must be a list of up to 40 text values`);
  }
  return [...new Set(value.map(v => (v as string).trim()))];
}

function nonNegativeNumber(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new HttpsError('invalid-argument', `${field} must be a non-negative number`);
  }
  return value;
}

function nonNegativeInteger(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new HttpsError('invalid-argument', `${field} must be a non-negative integer`);
  }
  return value;
}

// One shared product definition, two independently controlled branch stock records.
// All writes run on the trusted server; clients cannot write stock or cost documents directly.
export const addSharedProduct = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  await requireManager(request.auth.uid);

  const data = request.data ?? {};
  const name = cleanText(data.name, 'name');
  const sku = cleanText(data.sku, 'sku', 60);
  const category = typeof data.category === 'string' ? data.category.trim().slice(0, 80) : '';
  const colors = cleanList(data.colors, 'colors');
  const sizes = cleanList(data.sizes, 'sizes');
  const salePrice = nonNegativeNumber(data.salePrice, 'salePrice');
  const wholesaleCost = nonNegativeNumber(data.wholesaleCost, 'wholesaleCost');
  const quantities = data.branchQuantities;
  if (!quantities || typeof quantities !== 'object') {
    throw new HttpsError('invalid-argument', 'branchQuantities for branches 1 and 2 are required');
  }
  const qty1 = nonNegativeInteger(quantities['1'], 'branch 1 quantity');
  const qty2 = nonNegativeInteger(quantities['2'], 'branch 2 quantity');

  const normalizedSku = sku.toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
  const skuRef = db.doc(`sku_index/${normalizedSku}`);
  const productRef = db.collection('products').doc();
  const now = FieldValue.serverTimestamp();

  await db.runTransaction(async (tx) => {
    const existingSku = await tx.get(skuRef);
    if (existingSku.exists) throw new HttpsError('already-exists', 'هذا الكود مستخدم بالفعل لمنتج آخر');

    tx.create(productRef, {
      name, sku, category, colors, sizes, salePrice,
      active: true, createdAt: now, createdBy: request.auth!.uid,
    });
    tx.create(skuRef, { productId: productRef.id, createdAt: now });
    tx.create(db.doc(`products/${productRef.id}/private/cost`), {
      wholesaleCost, updatedAt: now, updatedBy: request.auth!.uid,
    });

    for (const [branchId, quantity] of [['1', qty1], ['2', qty2]] as const) {
      tx.create(db.doc(`branches/${branchId}/stock/${productRef.id}`), {
        productId: productRef.id, name, sku, category, salePrice,
        quantity, active: true, updatedAt: now,
      });
    }
  });

  return { ok: true, productId: productRef.id, branchQuantities: { '1': qty1, '2': qty2 } };
});

// Manager-only user provisioning. Create the Firebase Auth account in a trusted admin flow first.
export const setSellerProfile = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  await requireManager(request.auth.uid);
  const { uid, branchId, displayName } = request.data ?? {};
  if (typeof uid !== 'string' || ![1, 2].includes(branchId) || typeof displayName !== 'string') {
    throw new HttpsError('invalid-argument', 'uid, displayName and branchId (1 or 2) are required');
  }
  await db.doc(`users/${uid}`).set({ role: 'seller', branchId, displayName, active: true, createdAt: FieldValue.serverTimestamp() });
  return { ok: true };
});

// Idempotent server-side sale commit for both online and queued offline sales.
// The client never writes stock or sales documents directly.
export const syncOfflineSale = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  const uid = request.auth.uid;
  const profileSnap = await db.doc(`users/${uid}`).get();
  const profile = profileSnap.data();
  if (!profile || profile.active !== true || !['manager', 'admin', 'seller'].includes(profile.role)) {
    throw new HttpsError('permission-denied', 'الحساب غير مفعل');
  }

  const data = request.data ?? {};
  const operationId = cleanText(data.operationId, 'operationId', 150);
  const branchId = data.branchId;
  if (![1, 2].includes(branchId)) throw new HttpsError('invalid-argument', 'branchId must be 1 or 2');
  if (profile.role === 'seller' && profile.branchId !== branchId) {
    throw new HttpsError('permission-denied', 'لا يمكنك البيع في هذا الفرع');
  }
  const paymentMethod = data.paymentMethod;
  if (!['cash', 'instapay'].includes(paymentMethod)) throw new HttpsError('invalid-argument', 'طريقة الدفع غير صحيحة');
  if (!Array.isArray(data.items) || data.items.length < 1 || data.items.length > 60) {
    throw new HttpsError('invalid-argument', 'الفاتورة يجب أن تحتوي من 1 إلى 60 صنفًا');
  }

  const parsed = data.items.map((item: any) => ({
    productId: cleanText(item?.productId, 'productId', 150),
    quantity: nonNegativeInteger(item?.quantity, 'quantity'),
  }));
  if (parsed.some((x: any) => x.quantity < 1) || new Set(parsed.map((x: any) => x.productId)).size !== parsed.length) {
    throw new HttpsError('invalid-argument', 'كميات أو أصناف الفاتورة غير صحيحة');
  }

  const branchRef = db.doc(`branches/${branchId}`);
  const saleRef = branchRef.collection('sales').doc(operationId);
  const operationRef = db.doc(`offline_operations/${uid}_${operationId}`);
  const stockRefs = parsed.map((item: any) => branchRef.collection('stock').doc(item.productId));
  const costRefs = parsed.map((item: any) => db.doc(`products/${item.productId}/private/cost`));
  let resultTotal = 0;

  await db.runTransaction(async (tx) => {
    const previous = await tx.get(operationRef);
    if (previous.exists) { resultTotal = Number(previous.data()?.total ?? 0); return; }
    const salePrevious = await tx.get(saleRef);
    if (salePrevious.exists) { resultTotal = Number(salePrevious.data()?.total ?? 0); tx.create(operationRef, { saleId: saleRef.id, total: resultTotal, createdAt: FieldValue.serverTimestamp() }); return; }
    const stockSnaps: any[] = [];
    const costSnaps: any[] = [];
    for (const ref of stockRefs) stockSnaps.push(await tx.get(ref));
    for (const ref of costRefs) costSnaps.push(await tx.get(ref));

    const invoiceItems: any[] = [];
    let total = 0;
    let totalCost = 0;
    for (let i = 0; i < parsed.length; i++) {
      const snap = stockSnaps[i];
      if (!snap.exists || snap.data()?.active === false) throw new HttpsError('failed-precondition', 'أحد الأصناف غير متاح');
      const stock = snap.data()!;
      const available = Number(stock.quantity ?? 0);
      const quantity = parsed[i].quantity;
      if (!Number.isSafeInteger(available) || available < quantity) {
        throw new HttpsError('failed-precondition', `المخزون غير كافٍ للصنف ${stock.name ?? parsed[i].productId}`);
      }
      const unitPrice = Number(stock.salePrice ?? 0);
      if (!Number.isFinite(unitPrice) || unitPrice < 0) throw new HttpsError('failed-precondition', 'سعر بيع الصنف غير صالح');
      const lineTotal = unitPrice * quantity;
      const unitCost = Number(costSnaps[i].data()?.wholesaleCost ?? 0);
      if (!Number.isFinite(unitCost) || unitCost < 0) throw new HttpsError('failed-precondition', 'تكلفة الصنف غير صالحة');
      const lineCost = unitCost * quantity;
      total += lineTotal;
      totalCost += lineCost;
      invoiceItems.push({ productId: parsed[i].productId, name: stock.name ?? '', sku: stock.sku ?? '', quantity, unitPrice, unitCost, total: lineTotal, costTotal: lineCost });
    }

    for (let i = 0; i < parsed.length; i++) {
      tx.update(stockRefs[i], { quantity: Number(stockSnaps[i].data()!.quantity) - parsed[i].quantity, updatedAt: FieldValue.serverTimestamp() });
    }
    tx.create(saleRef, {
      branchId, type: 'sale', items: invoiceItems, total, totalCost, grossProfit: total - totalCost, paymentMethod,
      createdAt: FieldValue.serverTimestamp(), createdBy: uid,
      createdByName: typeof data.createdByName === 'string' ? data.createdByName.slice(0, 100) : '',
      operationId, syncedFromOffline: true,
      createdAtLocal: typeof data.createdAtLocal === 'string' ? data.createdAtLocal.slice(0, 40) : null,
    });
    tx.create(operationRef, { saleId: saleRef.id, total, createdAt: FieldValue.serverTimestamp() });
    resultTotal = total;
  });
  return { ok: true, saleId: saleRef.id, total: resultTotal, alreadySynced: false };
});
