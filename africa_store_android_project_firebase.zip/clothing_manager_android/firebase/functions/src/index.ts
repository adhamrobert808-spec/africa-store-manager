import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { onCall, HttpsError } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();

async function requireManager(uid: string) {
  const snap = await db.doc(`users/${uid}`).get();
  const u = snap.data();
  if (!u || u.active !== true || u.role !== 'manager') throw new HttpsError('permission-denied', 'Manager access required');
  return u;
}

// Create the first manager profile with a trusted Admin SDK script run by the project owner.
// Never expose first-manager bootstrap credentials inside the mobile app.

// Manager-only user provisioning. The caller must create the Firebase Auth user in a trusted admin flow,
// then invoke this callable with that user's UID and selected branch.
export const setSellerProfile = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  await requireManager(request.auth.uid);
  const { uid, branchId, displayName } = request.data ?? {};
  if (typeof uid !== 'string' || ![1, 2].includes(branchId) || typeof displayName !== 'string') {
    throw new HttpsError('invalid-argument', 'uid, displayName and branchId (1 or 2) are required');
  }
  await db.doc(`users/${uid}`).set({ role: 'seller', branchId, displayName, active: true, createdAt: FieldValue.serverTimestamp() });
  return { ok: true };
});

// Intentionally no client-side stock/sale write endpoint is enabled yet. Sales must be implemented
// as a transaction after validating product price, branch ownership, stock, and payment values.
