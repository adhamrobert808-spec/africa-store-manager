# إعداد Firebase داخل مشروع Flutter

تم وضع ملف `google-services.json` في المسار:
`android/app/google-services.json`

بيانات المطابقة التي تم التحقق منها:
- Firebase project: `africa-store-manager`
- Android package: `com.africastore.manager`

## ملاحظة مهمة
الحزمة الأصلية لا تحتوي على ملفات Android/Gradle (مثل `android/settings.gradle` و`android/app/build.gradle`)؛ لذلك إضافة ملف JSON وحدها لا تكفي لتفعيل Firebase أو إنتاج APK.

بعد توليد ملفات Android بواسطة Flutter (`flutter create . --platforms=android` من جذر المشروع)، طبّق إعداد Google Services plugin المتوافق مع إصدار Gradle/Android Gradle Plugin الذي ولّده Flutter، ثم نفّذ:
1. `flutter pub get`
2. `flutter analyze`
3. `flutter run`

وتأكد أن `firebase_core`, `firebase_auth`, و`cloud_firestore` مهيأة في التطبيق قبل الاستخدام.
لا تستخدم شاشة الدخول التجريبية الحالية لحماية بيانات حقيقية؛ فهي تسمح باختيار الدور ولا تتحقق من هوية المستخدم. يجب استكمال Firebase Authentication وقواعد Firestore وعمليات البيع الآمنة على الخادم أولاً.
