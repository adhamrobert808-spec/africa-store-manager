# Firebase deployment notes

The Firestore rules deliberately deny all client writes. This prevents a modified APK from bypassing stock and role controls. Do not loosen these rules to make the demo appear functional.

Before real use:
1. Create a Firebase project owned by the store owner.
2. Enable Authentication (email/password or phone) and Firestore.
3. Configure Android with `flutterfire configure` and add the generated `firebase_options.dart` locally (never commit private service-account keys).
4. Create the first manager profile using a trusted Admin SDK script run by the project owner; never bootstrap manager privileges from the public mobile client.
5. Implement and test callable transactional functions for sale, purchase, stock adjustment, inventory count, refunds, and daily close. The current source intentionally does not expose these writes.
6. Deploy rules and functions, test rules with the Firebase Emulator Suite, then test on two separate Android accounts/devices.

Data separation:
- Public product fields: name, salePrice, quantity, active.
- Wholesale cost: `branches/{branchId}/products/{productId}/private_cost/{docId}`; manager read only.
- Branch-specific sales and stock movements.
- Supplier purchases and monthly liabilities: manager read only.

The functions in this starter are scaffolding for provisioning only. They are not a complete production backend.
