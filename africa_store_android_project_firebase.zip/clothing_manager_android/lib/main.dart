import 'package:flutter/material.dart';

void main() => runApp(const ClothingManagerApp());

class ClothingManagerApp extends StatelessWidget {
  const ClothingManagerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'مدير افريقيا ستور',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF234A73)),
        scaffoldBackgroundColor: const Color(0xFFF5F7FA),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.white),
      ),
      home: const LoginScreen(),
    );
  }
}

enum UserRole { manager, seller }

class Session {
  final UserRole role;
  final int? branch;
  const Session.manager() : role = UserRole.manager, branch = null;
  const Session.seller(this.branch) : role = UserRole.seller;
  bool get isManager => role == UserRole.manager;
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _user = TextEditingController();
  final _pin = TextEditingController();
  String _branch = '1';
  String _role = 'manager';
  bool _hidePin = true;

  void _login() {
    // DEMO ONLY: replace with Firebase Authentication + server-side role claims.
    final session = _role == 'manager'
        ? const Session.manager()
        : Session.seller(int.parse(_branch));
    Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(session: session)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440), child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.storefront, size: 54, color: Color(0xFF234A73)),
          const SizedBox(height: 12), const Text('مدير افريقيا ستور', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6), const Text('تسجيل الدخول', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 24),
          TextField(controller: _user, textDirection: TextDirection.rtl, decoration: const InputDecoration(labelText: 'اسم المستخدم', prefixIcon: Icon(Icons.person_outline), border: OutlineInputBorder())),
          const SizedBox(height: 14),
          TextField(controller: _pin, obscureText: _hidePin, keyboardType: TextInputType.number, textDirection: TextDirection.rtl, decoration: InputDecoration(labelText: 'كلمة المرور / PIN', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_hidePin ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hidePin = !_hidePin)), border: const OutlineInputBorder())),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(value: _role, decoration: const InputDecoration(labelText: 'نوع الحساب', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 'manager', child: Text('مدير')), DropdownMenuItem(value: 'seller', child: Text('بائع'))], onChanged: (v) => setState(() => _role = v ?? 'manager')),
          if (_role == 'seller') ...[
            const SizedBox(height: 14),
            DropdownButtonFormField<String>(value: _branch, decoration: const InputDecoration(labelText: 'الفرع', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: '1', child: Text('افريقيا ستور الهرم')), DropdownMenuItem(value: '2', child: Text('افريقيا ستور اكتوبر'))], onChanged: (v) => setState(() => _branch = v ?? '1')),
          ],
          const SizedBox(height: 20), FilledButton.icon(onPressed: _login, icon: const Icon(Icons.login), label: const Padding(padding: EdgeInsets.all(12), child: Text('دخول'))),
          const SizedBox(height: 12), const Text('نسخة تصميم أولية — تسجيل الدخول تجريبي وليس آمناً للاستخدام الفعلي بعد.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.deepOrange)),
        ],
      ))))))),
  );
}

class HomeScreen extends StatefulWidget {
  final Session session;
  const HomeScreen({super.key, required this.session});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  @override
  Widget build(BuildContext context) {
    final manager = widget.session.isManager;
    final pages = manager
      ? <Widget>[const DashboardScreen(), const InventoryScreen(branch: 1, manager: true), const InventoryScreen(branch: 2, manager: true), const ReportsScreen(), const StaffScreen()]
      : <Widget>[SellerScreen(branch: widget.session.branch!), InventoryScreen(branch: widget.session.branch!, manager: false)];
    final titles = manager ? ['لوحة المدير', 'مخزون افريقيا ستور الهرم', 'مخزون افريقيا ستور اكتوبر', 'التقارير والحسابات', 'المستخدمون'] : ['مبيعات ${widget.session.branch == 1 ? 'الهرم' : 'اكتوبر'}', 'مخزون ${widget.session.branch == 1 ? 'الهرم' : 'اكتوبر'}'];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(titles[_index]), actions: [IconButton(tooltip: 'خروج', onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen())), icon: const Icon(Icons.logout))]),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (v) => setState(() => _index = v), destinations: manager ? const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 1'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 2'), NavigationDestination(icon: Icon(Icons.assessment_outlined), label: 'التقارير'), NavigationDestination(icon: Icon(Icons.people_outline), label: 'المستخدمون')] : const [NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'المبيعات'), NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المخزون')]),
    ));
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('ملخص اليوم', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    const Wrap(spacing: 12, runSpacing: 12, children: [MetricCard(title: 'مبيعات الهرم', value: '—', icon: Icons.store), MetricCard(title: 'مبيعات اكتوبر', value: '—', icon: Icons.storefront), MetricCard(title: 'إجمالي المشتريات', value: '—', icon: Icons.shopping_cart), MetricCard(title: 'مستحق للموردين', value: '—', icon: Icons.account_balance_wallet)]),
    const SizedBox(height: 18), const Text('إجراءات المدير', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    ActionTile(icon: Icons.add_box_outlined, title: 'إضافة منتج', subtitle: 'إضافة منتج وسعر الجملة والبيع والرصيد', onTap: () => _notice(context)),
    ActionTile(icon: Icons.local_shipping_outlined, title: 'تسجيل مشتريات جملة', subtitle: 'تسجيل فاتورة المورد والمدفوع والمتبقي', onTap: () => _notice(context)),
    ActionTile(icon: Icons.fact_check_outlined, title: 'بدء جرد', subtitle: 'جرد كل فرع بشكل مستقل', onTap: () => _notice(context)),
  ]);
  static void _notice(BuildContext c) => ScaffoldMessenger.of(c).showSnackBar(const SnackBar(content: Text('هذه الوظيفة ضمن مرحلة ربط قاعدة البيانات.')));
}

class MetricCard extends StatelessWidget {
  final String title, value; final IconData icon;
  const MetricCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => SizedBox(width: 165, child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFF234A73)), const SizedBox(height: 12), Text(value, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), Text(title, style: const TextStyle(fontSize: 12, color: Colors.black54))]))));
}

class SellerScreen extends StatelessWidget {
  final int branch; const SellerScreen({super.key, required this.branch});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('نقطة بيع — ${branch == 1 ? 'افريقيا ستور الهرم' : 'افريقيا ستور اكتوبر'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 8), const Text('ابحث عن المنتج وأدخل الكمية ثم سجّل عملية البيع.'), const SizedBox(height: 16), const TextField(decoration: InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'اسم المنتج أو الكود', border: OutlineInputBorder())), const SizedBox(height: 12), const TextField(keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'الكمية', border: OutlineInputBorder())), const SizedBox(height: 12), const TextField(keyboardType: TextInputType.number, decoration: InputDecoration(labelText: 'سعر البيع', border: OutlineInputBorder())), const SizedBox(height: 16), FilledButton.icon(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيتم تفعيل حفظ البيع بعد ربط قاعدة البيانات.'))), icon: const Icon(Icons.receipt_long), label: const Text('إتمام البيع وإصدار PDF'))]))),
    const Card(elevation: 0, child: ListTile(leading: Icon(Icons.lock_outline), title: Text('بيانات محمية حسب الفرع'), subtitle: Text('سعر الجملة وأرصدة الفرع الآخر غير متاحة لحساب البائع.'))),
  ]);
}

class InventoryScreen extends StatelessWidget {
  final int branch; final bool manager;
  const InventoryScreen({super.key, required this.branch, required this.manager});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [Expanded(child: Text('مخزون ${branch == 1 ? 'افريقيا ستور الهرم' : 'افريقيا ستور اكتوبر'}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), if (manager) FilledButton.icon(onPressed: () => _add(context), icon: const Icon(Icons.add), label: const Text('إضافة منتج'))]),
    const SizedBox(height: 12), const Card(elevation: 0, child: Padding(padding: EdgeInsets.all(24), child: Column(children: [Icon(Icons.inventory_2_outlined, size: 44, color: Colors.black38), SizedBox(height: 8), Text('لا توجد منتجات بعد'), Text('ستظهر المنتجات وأرصدة هذا الفرع هنا.', style: TextStyle(color: Colors.black54))]))),
    if (manager) const Padding(padding: EdgeInsets.only(top: 12), child: Text('سعر الجملة ظاهر للمدير فقط.', style: TextStyle(color: Colors.black54))),
  ]);
  void _add(BuildContext context) => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('إضافة منتج'), content: const Text('سيتم تفعيل نموذج المنتج عند ربط قاعدة البيانات.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إغلاق'))]));
}

class ReportsScreen extends StatelessWidget {
  const ReportsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    Text('تقارير المدير', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    ActionTile(icon: Icons.today, title: 'تقرير نهاية اليوم', subtitle: 'مبيعات كل فرع على حدة'),
    ActionTile(icon: Icons.calendar_month, title: 'التقرير الشهري', subtitle: 'المبيعات والمشتريات والمدفوع والمتبقي'),
    ActionTile(icon: Icons.inventory, title: 'تقرير الجرد', subtitle: 'الرصيد الدفتري والفعلي والعجز والزيادة'),
    ActionTile(icon: Icons.picture_as_pdf, title: 'تصدير PDF', subtitle: 'تقارير وفواتير قابلة للطباعة والمشاركة'),
  ]);
}

class StaffScreen extends StatelessWidget {
  const StaffScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [const Expanded(child: Text('إدارة المستخدمين', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), FilledButton.icon(onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('إضافة بائع'), content: const Text('سيتم إنشاء حسابات البائعين وربطها بفرع محدد من لوحة المدير.'), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسناً'))])), icon: const Icon(Icons.person_add), label: const Text('إضافة بائع'))]),
    const SizedBox(height: 12), const Card(elevation: 0, child: ListTile(leading: Icon(Icons.admin_panel_settings), title: Text('المدير الرئيسي'), subtitle: Text('صلاحية الفرعين والتقارير والإعدادات'))),
  ]);
}

class ActionTile extends StatelessWidget {
  final IconData icon; final String title, subtitle; final VoidCallback? onTap;
  const ActionTile({super.key, required this.icon, required this.title, required this.subtitle, this.onTap});
  @override
  Widget build(BuildContext context) => Card(elevation: 0, child: ListTile(leading: Icon(icon, color: const Color(0xFF234A73)), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_left), onTap: onTap));
}
