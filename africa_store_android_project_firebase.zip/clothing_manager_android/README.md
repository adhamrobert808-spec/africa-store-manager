# مدير افريقيا ستور — مشروع Android

تطبيق Flutter عربي لإدارة فرعين:
- افريقيا ستور الهرم (branchId = 1)
- افريقيا ستور اكتوبر (branchId = 2)

## المعتمد
- Android، واجهة عربية RTL.
- مدير يرى الفرعين وكافة التقارير والتكلفة.
- بائع مربوط بفرع واحد.
- مخزون مبسط: اسم المنتج والكمية.
- سعر الجملة لا يُرسل إلى حساب البائع؛ مكانه المقترح مجموعة خاصة منفصلة.
- فواتير وتقارير PDF عبر حزم `pdf` و`printing`.
- Firebase Authentication وCloud Firestore للمزامنة.

## الحالة بدقة
هذا **مشروع تأسيسي/نموذج واجهات** يحمل أسماء الفرعين الفعلية، ومعه مسودة قواعد أمان Firestore وهيكل Cloud Functions. ليس APK جاهزاً للبيع أو للاستخدام المحاسبي بعد. لا يوجد مشروع Firebase مملوك للمتجر أو إعداد Android Firebase أو حسابات دخول حقيقية ضمن هذه الحزمة، كما أن حفظ المبيعات والمشتريات والجرد وتوليد PDF الفعلي لم تُفعّل بعد. شاشة الدخول في `lib/main.dart` تجريبية وتسمح باختيار الدور؛ لا تستخدمها لحماية بيانات حقيقية.

## تشغيل واجهة النموذج
1. تثبيت Flutter SDK وAndroid Studio.
2. من مجلد المشروع: `flutter pub get`
3. `flutter run`

## تجهيز نسخة تشغيلية آمنة
راجع `firebase/README.md`. يلزم إنشاء Firebase باسم المالك وربط التطبيق به، ثم إكمال وظائف الخادم المعاملاتية واختبار قواعد الصلاحيات قبل تسجيل أي مبيعات حقيقية. لا تضع مفاتيح service account أو كلمات مرور في المحادثة أو داخل APK.

## قاعدة البيانات المقترحة
- `users/{uid}`: role, branchId, active, displayName.
- `branches/{branchId}/products/{productId}`: name, quantity, salePrice, active.
- `branches/{branchId}/products/{productId}/private_cost/{docId}`: wholesaleCost (manager only).
- `branches/{branchId}/sales/{saleId}`: invoiceNo, items, total, paid, paymentMethod, sellerUid, createdAt.
- `purchases/{purchaseId}`: supplier, branchId, total, paid, remaining, createdAt (manager only).
- `stock_movements/{movementId}` و`inventory_counts/{countId}`.

## مبدأ أمني أساسي
لا يكفي إخفاء سعر الجملة من الواجهة. يجب ألا يملك حساب البائع إذن قراءة سجل التكلفة أصلاً. كذلك يجب أن تنفذ عمليات البيع وتعديل المخزون من Cloud Functions داخل معاملات ذرية، لا من التطبيق مباشرة.


## تحديث ربط Firebase
تمت إضافة `android/app/google-services.json` للمشروع `africa-store-manager` وحزمة Android `com.africastore.manager`.
راجع `firebase/ANDROID_FIREBASE_SETUP.md` لاستكمال ملفات Android/Gradle وتفعيل الإضافة.
هذا لا يحوّل النموذج إلى نسخة تشغيلية ولا ينتج APK تلقائياً.
