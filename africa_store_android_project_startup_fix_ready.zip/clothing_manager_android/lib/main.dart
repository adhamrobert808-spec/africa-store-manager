import 'dart:async';
import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  Object? startupError;
  try {
    // Explicit options avoid relying solely on generated Android resources.
    await Firebase.initializeApp(
      options: const FirebaseOptions(
        apiKey: 'AIzaSyAjjtEjykC752Qr9CN6RwzOjh3GVfMUlUc',
        appId: '1:586765819345:android:64413f29ab46927a1714f0',
        messagingSenderId: '586765819345',
        projectId: 'africa-store-manager',
        storageBucket: 'africa-store-manager.firebasestorage.app',
      ),
    );
  } catch (e) {
    startupError = e;
  }
  runApp(AfricaStoreApp(startupError: startupError));
}


class AfricaStoreApp extends StatelessWidget {
  final Object? startupError;
  const AfricaStoreApp({super.key, this.startupError});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'مدير افريقيا ستور',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF234A73)),
          scaffoldBackgroundColor: const Color(0xFFF5F7FA),
          fontFamily: 'Arial',
        ),
        home: startupError == null
            ? const LoginScreen()
            : FirebaseStartupErrorScreen(error: startupError.toString()),
      );
}

class FirebaseStartupErrorScreen extends StatelessWidget {
  final String error;
  const FirebaseStartupErrorScreen({super.key, required this.error});

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.cloud_off, size: 56, color: Colors.red),
                const SizedBox(height: 16),
                const Text('تعذر الاتصال بخدمات Firebase', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
                const SizedBox(height: 12),
                const Text('التطبيق لم يُغلق. أرسل صورة هذه الرسالة للدعم الفني.', textAlign: TextAlign.center),
                const SizedBox(height: 12),
                SelectableText(error, textAlign: TextAlign.left),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}


/// Commits a sale atomically using Firestore only (no Cloud Functions).
/// The same operationId makes retries safe if the network drops after commit.
Future<double> commitSaleToFirestore(Map<String, dynamic> sale) async {
  final user = FirebaseAuth.instance.currentUser;
  if (user == null) throw StateError('يجب تسجيل الدخول أولاً');
  final branchId = (sale['branchId'] as num?)?.toInt();
  if (branchId != 1 && branchId != 2) throw ArgumentError('الفرع غير صحيح');
  final operationId = sale['operationId']?.toString();
  if (operationId == null || operationId.isEmpty) throw ArgumentError('رقم العملية غير صحيح');
  final paymentMethod = sale['paymentMethod']?.toString();
  if (paymentMethod != 'cash' && paymentMethod != 'instapay') {
    throw ArgumentError('طريقة الدفع غير صحيحة');
  }
  final rawItems = sale['items'];
  if (rawItems is! List || rawItems.isEmpty) throw ArgumentError('الفاتورة فارغة');

  final db = FirebaseFirestore.instance;
  final branchRef = db.collection('branches').doc('$branchId');
  final saleRef = branchRef.collection('sales').doc(operationId);
  final lines = rawItems.map((item) {
    if (item is! Map) throw ArgumentError('بيانات صنف غير صحيحة');
    final productId = item['productId']?.toString() ?? '';
    final quantity = (item['quantity'] as num?)?.toInt() ?? 0;
    if (productId.isEmpty || quantity < 1) throw ArgumentError('كمية أو كود صنف غير صحيح');
    return {'productId': productId, 'quantity': quantity};
  }).toList();
  if (lines.map((e) => e['productId']).toSet().length != lines.length) {
    throw ArgumentError('يوجد صنف مكرر في الفاتورة');
  }
  final stockRefs = lines.map((line) =>
      branchRef.collection('stock').doc(line['productId'] as String)).toList();

  return db.runTransaction<double>((tx) async {
    final existingSale = await tx.get(saleRef);
    if (existingSale.exists) {
      return (existingSale.data()?['total'] as num?)?.toDouble() ?? 0;
    }

    final stockSnapshots = <DocumentSnapshot<Map<String, dynamic>>>[];
    for (final ref in stockRefs) {
      stockSnapshots.add(await tx.get(ref));
    }

    final invoiceItems = <Map<String, dynamic>>[];
    var total = 0.0;
    for (var i = 0; i < lines.length; i++) {
      final snapshot = stockSnapshots[i];
      if (!snapshot.exists || snapshot.data()?['active'] == false) {
        throw StateError('أحد الأصناف غير متاح في المخزون');
      }
      final stock = snapshot.data()!;
      final available = (stock['quantity'] as num?)?.toInt() ?? 0;
      final quantity = lines[i]['quantity'] as int;
      if (available < quantity) {
        throw StateError('المخزون غير كافٍ للصنف ${stock['name'] ?? ''}');
      }
      final unitPrice = (stock['salePrice'] as num?)?.toDouble() ?? 0;
      if (unitPrice < 0) throw StateError('سعر بيع الصنف غير صالح');
      final lineTotal = unitPrice * quantity;
      total += lineTotal;
      invoiceItems.add({
        'productId': lines[i]['productId'],
        'name': stock['name'] ?? '',
        'sku': stock['sku'] ?? '',
        'quantity': quantity,
        'unitPrice': unitPrice,
        'total': lineTotal,
      });
    }

    for (var i = 0; i < lines.length; i++) {
      final currentQty = (stockSnapshots[i].data()?['quantity'] as num).toInt();
      tx.update(stockRefs[i], {
        'quantity': currentQty - (lines[i]['quantity'] as int),
        'updatedAt': FieldValue.serverTimestamp(),
      });
    }
    tx.set(saleRef, {
      'branchId': branchId,
      'type': 'sale',
      'items': invoiceItems,
      'total': total,
      'paymentMethod': paymentMethod,
      'createdAt': FieldValue.serverTimestamp(),
      'createdBy': user.uid,
      'createdByName': (sale['createdByName'] ?? user.displayName ?? user.email ?? 'بائع').toString(),
      'operationId': operationId,
      'createdAtLocal': sale['createdAtLocal'],
    });
    return total;
  });
}

/// Persistent device outbox. Pending sales are committed to Firestore
/// when connectivity returns; operationId prevents duplicate invoices.
class OfflineSalesOutbox {
  static const _key = 'africa_store_pending_sales_v1';
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static Future<int> reservedQuantity(int branchId, String productId) async {
    final items = await pending();
    var quantity = 0;
    for (final sale in items) {
      if (sale['status'] == 'needs_review' || sale['branchId'] != branchId) continue;
      final lines = sale['items'];
      if (lines is! List) continue;
      for (final line in lines) {
        if (line is Map && line['productId'] == productId) {
          quantity += (line['quantity'] as num?)?.toInt() ?? 0;
        }
      }
    }
    return quantity;
  }

  static Future<List<Map<String, dynamic>>> pending() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    try {
      return (jsonDecode(raw) as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
    } catch (_) { return []; }
  }

  static Future<void> _save(List<Map<String, dynamic>> items) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key, jsonEncode(items));
  }

  static Future<void> enqueue(Map<String, dynamic> sale) async {
    final items = await pending();
    if (!items.any((e) => e['operationId'] == sale['operationId'])) {
      items.add(sale);
      await _save(items);
      revision.value++;
    }
  }

  static Future<int> sync() async {
    final items = await pending();
    if (items.isEmpty || FirebaseAuth.instance.currentUser == null) return 0;
    final remaining = <Map<String, dynamic>>[];
    var synced = 0;
    for (final sale in items) {
      if (sale['status'] == 'needs_review') { remaining.add(sale); continue; }
      try {
        await commitSaleToFirestore(sale);
        synced++;
      } on FirebaseException catch (e) {
        if (e.code == 'failed-precondition' || e.code == 'permission-denied' || e.code == 'invalid-argument') {
          remaining.add({...sale, 'status': 'needs_review', 'syncError': e.message ?? e.code});
        } else {
          remaining.add(sale);
        }
      } catch (e) {
        remaining.add(sale);
      }
    }
    await _save(remaining);
    if (synced > 0 || remaining.length != items.length) revision.value++;
    return synced;
  }
}

class StoreSession {
  final String uid;
  final String role;
  final int? branchId;
  final String displayName;
  const StoreSession({required this.uid, required this.role, required this.displayName, this.branchId});
  bool get isManager => role == 'manager' || role == 'admin';
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _restoreSessionFromCache();
  }

  Future<void> _restoreSessionFromCache() async {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;
    try {
      final profile = await FirebaseFirestore.instance.collection('users').doc(user.uid).get(const GetOptions(source: Source.cache));
      final data = profile.data();
      if (!profile.exists || data?['active'] != true || !['manager', 'admin', 'seller'].contains(data?['role'])) return;
      final role = data!['role'] == 'admin' ? 'manager' : data['role'] as String;
      final branchId = data['branchId'] is int ? data['branchId'] as int : null;
      if (role == 'seller' && branchId != 1 && branchId != 2) return;
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => HomeScreen(session: StoreSession(
        uid: user.uid, role: role, branchId: branchId,
        displayName: (data['displayName'] ?? user.email ?? 'مستخدم').toString(),
      ))));
    } catch (_) {
      // No cached profile: keep the login screen and wait for connectivity.
    }
  }

  Future<void> _login() async {
    setState(() { _busy = true; _error = null; });
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(), password: _password.text,
      );
      final uid = credential.user!.uid;
      final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final data = profile.data();
      if (!profile.exists || data?['active'] != true || !['manager', 'admin', 'seller'].contains(data?['role'])) {
        await FirebaseAuth.instance.signOut();
        throw Exception('الحساب غير مفعل. راجع مدير النظام لإعداد الصلاحيات.');
      }
      final storedRole = data!['role'] as String;
      final role = storedRole == 'admin' ? 'manager' : storedRole;
      final branchId = data['branchId'] is int ? data['branchId'] as int : null;
      if (role == 'seller' && branchId != 1 && branchId != 2) {
        await FirebaseAuth.instance.signOut();
        throw Exception('لم يتم ربط حساب البائع بفرع صحيح.');
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => HomeScreen(session: StoreSession(
          uid: uid, role: role, branchId: branchId,
          displayName: (data['displayName'] ?? _email.text.trim()).toString(),
        )),
      ));
    } on FirebaseAuthException catch (e) {
      setState(() => _error = e.code == 'user-not-found' || e.code == 'wrong-password' || e.code == 'invalid-credential'
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'تعذر تسجيل الدخول: ${e.message ?? e.code}');
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440), child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.storefront, size: 54, color: Color(0xFF234A73)),
          const SizedBox(height: 12), const Text('مدير افريقيا ستور', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6), const Text('تسجيل الدخول الآمن', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 24),
          TextField(controller: _email, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder())),
          const SizedBox(height: 14),
          TextField(controller: _password, obscureText: _hide, decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)), border: const OutlineInputBorder())),
          if (_error != null) ...[const SizedBox(height: 12), Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)],
          const SizedBox(height: 20), FilledButton.icon(onPressed: _busy ? null : _login, icon: const Icon(Icons.login), label: Padding(padding: const EdgeInsets.all(12), child: Text(_busy ? 'جارٍ التحقق...' : 'دخول'))),
          const SizedBox(height: 12), const Text('يتطلب حساب Firebase مفعّلاً وصلاحية محددة من مدير النظام.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      ))))))),
  ));
}

class HomeScreen extends StatefulWidget {
  final StoreSession session;
  const HomeScreen({super.key, required this.session});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  late final StreamSubscription<List<ConnectivityResult>> _connectivitySub;
  late final Timer _syncRetryTimer;
  @override
  void initState() {
    super.initState();
    OfflineSalesOutbox.sync();
    _connectivitySub = Connectivity().onConnectivityChanged.listen((results) {
      if (results.any((r) => r != ConnectivityResult.none)) OfflineSalesOutbox.sync();
    });
    // Retry queued invoices periodically as some Android networks do not emit
    // a connectivity transition when internet access is restored.
    _syncRetryTimer = Timer.periodic(const Duration(seconds: 30), (_) => OfflineSalesOutbox.sync());
  }
  @override
  void dispose() { _connectivitySub.cancel(); _syncRetryTimer.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    final pages = s.isManager
        ? <Widget>[const DashboardScreen(), const InventoryScreen(branch: 1, manager: true), const InventoryScreen(branch: 2, manager: true), const WholesaleAccountsScreen()]
        : <Widget>[InventoryScreen(branch: s.branchId!, manager: false)];
    final titles = s.isManager ? ['لوحة المدير والجرد', 'مخزون افريقيا ستور الهرم', 'مخزون افريقيا ستور اكتوبر', 'حسابات الجملة والدفعات'] : ['مخزون ${s.branchId == 1 ? 'الهرم' : 'اكتوبر'}'];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(titles[_index]), actions: [IconButton(tooltip: 'خروج', onPressed: () async { await FirebaseAuth.instance.signOut(); if (context.mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen())); }, icon: const Icon(Icons.logout))]),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (v) => setState(() => _index = v), destinations: s.isManager
          ? const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 1'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 2'), NavigationDestination(icon: Icon(Icons.payments_outlined), label: 'الجملة والدفعات')]
          : const [NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المخزون')]),
    ));
  }
}


class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  Future<Map<String, dynamic>> _branchTotals(int branch) async {
    final db = FirebaseFirestore.instance;
    final branchRef = db.collection('branches').doc('$branch');
    final docs = await branchRef.collection('stock').get();
    final salesDocs = await branchRef.collection('sales').where('type', isEqualTo: 'sale').get();
    double wholesale = 0, retail = 0, salesTotal = 0, grossProfit = 0;
    for (final saleDoc in salesDocs.docs) {
      final sale = saleDoc.data();
      salesTotal += (sale['total'] as num?)?.toDouble() ?? 0;
      grossProfit += (sale['grossProfit'] as num?)?.toDouble() ?? 0;
    }
    int units = 0;
    final rows = <Map<String, dynamic>>[];
    for (final doc in docs.docs) {
      final d = doc.data();
      final qty = (d['quantity'] as num?)?.toInt() ?? 0;
      final sale = (d['salePrice'] as num?)?.toDouble() ?? 0;
      double cost = 0;
      try {
        final c = await db.collection('products').doc(doc.id).collection('private').doc('cost').get();
        cost = (c.data()?['wholesaleCost'] as num?)?.toDouble() ?? 0;
      } catch (_) {}
      units += qty; retail += qty * sale; wholesale += qty * cost;
      rows.add({'name': d['name'] ?? '', 'sku': d['sku'] ?? '', 'qty': qty, 'sale': sale, 'cost': cost, 'retail': qty * sale, 'wholesale': qty * cost});
    }
    return {'units': units, 'retail': retail, 'wholesale': wholesale, 'salesTotal': salesTotal, 'grossProfit': grossProfit, 'salesCount': salesDocs.docs.length, 'rows': rows};
  }

  void _openReport(BuildContext context, int branch) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => BranchInventoryReportScreen(branch: branch)));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('إدارة أفريقيا ستور', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('ملخص قيمة المخزون حسب الفرع — التكلفة بالجملة وسعر البيع للكمية المتاحة'),
    const SizedBox(height: 12),
    for (final branch in [1, 2])
      FutureBuilder<Map<String, dynamic>>(future: _branchTotals(branch), builder: (context, snap) {
        final title = branch == 1 ? 'فرع الهرم' : 'فرع أكتوبر';
        if (snap.hasError) return Card(child: ListTile(title: Text(title), subtitle: Text('تعذر حساب الإجمالي: ${snap.error}')));
        if (!snap.hasData) return Card(child: ListTile(title: Text(title), subtitle: const LinearProgressIndicator()));
        final d = snap.data!;
        return Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
          Text('إجمالي القطع: ${d['units']}'),
          Text('قيمة البضاعة بالجملة: ${(d['wholesale'] as double).toStringAsFixed(2)} جنيه'),
          Text('إجمالي سعر البيع للمخزون: ${(d['retail'] as double).toStringAsFixed(2)} جنيه'),
          const Divider(),
          Text('عدد الفواتير المعتمدة: ${d['salesCount']}'),
          Text('إجمالي المبيعات: ${(d['salesTotal'] as double).toStringAsFixed(2)} جنيه'),
          Text('مجمل الربح المسجل: ${(d['grossProfit'] as double).toStringAsFixed(2)} جنيه'),
          const SizedBox(height: 8),
          OutlinedButton.icon(onPressed: () => _openReport(context, branch), icon: const Icon(Icons.assessment_outlined), label: const Text('تقرير جرد تفصيلي للفرع')),
        ])));
      }),
    const Card(elevation: 0, child: ListTile(leading: Icon(Icons.security), title: Text('صلاحيات محمية'), subtitle: Text('المدير يرى الفرعين، والبائع يعمل على مخزون فرعه فقط.'))),
  ]);
}

class BranchInventoryReportScreen extends StatelessWidget {
  final int branch;
  const BranchInventoryReportScreen({super.key, required this.branch});

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('branches').doc('$branch').collection('stock').orderBy('name').snapshots();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text('تقرير جرد ${branch == 1 ? 'الهرم' : 'أكتوبر'}')),
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stream, builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('تعذر تحميل الجرد: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        return FutureBuilder<List<Map<String, dynamic>>>(future: Future.wait(docs.map((doc) async {
          final d = doc.data();
          final qty = (d['quantity'] as num?)?.toInt() ?? 0;
          final sale = (d['salePrice'] as num?)?.toDouble() ?? 0;
          double cost = 0;
          final c = await FirebaseFirestore.instance.collection('products').doc(doc.id).collection('private').doc('cost').get();
          cost = (c.data()?['wholesaleCost'] as num?)?.toDouble() ?? 0;
          return {'name': d['name'] ?? '', 'sku': d['sku'] ?? '', 'qty': qty, 'sale': sale, 'cost': cost, 'retail': qty * sale, 'wholesale': qty * cost};
        })), builder: (context, rowsSnap) {
          if (!rowsSnap.hasData) return const Center(child: CircularProgressIndicator());
          final rows = rowsSnap.data!;
          final units = rows.fold<int>(0, (a, r) => a + (r['qty'] as int));
          final retail = rows.fold<double>(0, (a, r) => a + (r['retail'] as double));
          final wholesale = rows.fold<double>(0, (a, r) => a + (r['wholesale'] as double));
          return ListView(padding: const EdgeInsets.all(12), children: [
            Card(elevation: 0, child: ListTile(title: const Text('إجمالي الفرع'), subtitle: Text('عدد القطع: $units\nالجملة: ${wholesale.toStringAsFixed(2)} جنيه\nسعر البيع: ${retail.toStringAsFixed(2)} جنيه'))),
            ...rows.map((r) => Card(elevation: 0, child: ListTile(
              title: Text('${r['name']}'),
              subtitle: Text('الكود: ${r['sku']} • الكمية: ${r['qty']}\nجملة الوحدة: ${r['cost']} • بيع الوحدة: ${r['sale']}\nإجمالي الجملة: ${(r['wholesale'] as double).toStringAsFixed(2)} • إجمالي البيع: ${(r['retail'] as double).toStringAsFixed(2)}'),
              isThreeLine: true,
            ))),
          ]);
        });
      }),
    ));
  }
}

class WholesaleAccountsScreen extends StatefulWidget {
  const WholesaleAccountsScreen({super.key});
  @override
  State<WholesaleAccountsScreen> createState() => _WholesaleAccountsScreenState();
}

class _WholesaleAccountsScreenState extends State<WholesaleAccountsScreen> {
  Future<void> _addPurchase() async {
    final supplier = TextEditingController();
    final total = TextEditingController();
    final paid = TextEditingController(text: '0');
    final note = TextEditingController();
    int branch = 1;
    String? error;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
      title: const Text('تسجيل فاتورة بضاعة بالجملة'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: supplier, decoration: const InputDecoration(labelText: 'اسم المورد', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        DropdownButtonFormField<int>(value: branch, decoration: const InputDecoration(labelText: 'الفرع', border: OutlineInputBorder()), items: const [DropdownMenuItem(value: 1, child: Text('الهرم')), DropdownMenuItem(value: 2, child: Text('أكتوبر'))], onChanged: (v) => setD(() => branch = v ?? 1)),
        const SizedBox(height: 8),
        TextField(controller: total, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'إجمالي قيمة البضاعة بالجملة', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: paid, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المدفوع', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: note, decoration: const InputDecoration(labelText: 'ملاحظات / رقم الفاتورة', border: OutlineInputBorder())),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final t = double.tryParse(total.text.trim()), p = double.tryParse(paid.text.trim());
          if (supplier.text.trim().isEmpty || t == null || p == null || t <= 0 || p < 0 || p > t) { setD(() => error = 'راجع اسم المورد والمبالغ؛ المدفوع لا يتجاوز الإجمالي.'); return; }
          try {
            await FirebaseFirestore.instance.collection('purchases').add({
              'supplier': supplier.text.trim(), 'branchId': branch, 'total': t, 'paid': p, 'remaining': t - p,
              'note': note.text.trim(), 'createdAt': FieldValue.serverTimestamp(), 'createdBy': FirebaseAuth.instance.currentUser!.uid,
            });
            if (ctx.mounted) Navigator.pop(ctx);
          } catch (e) { setD(() => error = 'تعذر الحفظ: $e'); }
        }, child: const Text('حفظ الفاتورة')),
      ],
    ))));
    supplier.dispose(); total.dispose(); paid.dispose(); note.dispose();
  }

  Future<void> _pay(DocumentSnapshot<Map<String, dynamic>> doc) async {
    final amount = TextEditingController();
    String? error;
    await showDialog<void>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setD) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
      title: const Text('تسجيل دفعة للمورد'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        Text('المتبقي: ${doc.data()?['remaining'] ?? 0} جنيه'),
        TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قيمة الدفعة', border: OutlineInputBorder())),
        if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final a = double.tryParse(amount.text.trim());
          final d = doc.data()!;
          final rem = (d['remaining'] as num).toDouble();
          if (a == null || a <= 0 || a > rem) { setD(() => error = 'أدخل دفعة صحيحة لا تتجاوز المتبقي.'); return; }
          try {
            await FirebaseFirestore.instance.runTransaction((tx) async {
              final fresh = await tx.get(doc.reference);
              final current = (fresh.data()?['remaining'] as num).toDouble();
              if (a > current) throw StateError('المتبقي تغير. حدّث الصفحة.');
              final newPaid = ((fresh.data()?['paid'] as num).toDouble()) + a;
              tx.update(doc.reference, {'paid': newPaid, 'remaining': current - a, 'lastPaymentAt': FieldValue.serverTimestamp()});
            });
            if (ctx.mounted) Navigator.pop(ctx);
          } catch (e) { setD(() => error = 'تعذر تسجيل الدفعة: $e'); }
        }, child: const Text('تأكيد الدفعة')),
      ],
    ))));
    amount.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('purchases').orderBy('createdAt', descending: true).snapshots();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stream, builder: (context, snap) {
        if (snap.hasError) return Center(child: Text('تعذر تحميل حسابات الجملة: ${snap.error}'));
        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
        final docs = snap.data!.docs;
        final total = docs.fold<double>(0, (a, d) => a + ((d.data()['total'] as num?)?.toDouble() ?? 0));
        final paid = docs.fold<double>(0, (a, d) => a + ((d.data()['paid'] as num?)?.toDouble() ?? 0));
        final remaining = docs.fold<double>(0, (a, d) => a + ((d.data()['remaining'] as num?)?.toDouble() ?? 0));
        return ListView(padding: const EdgeInsets.all(16), children: [
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _addPurchase, icon: const Icon(Icons.add), label: const Text('تسجيل فاتورة / مديونية جملة'))),
          Card(elevation: 0, child: ListTile(title: const Text('إجمالي حسابات الجملة'), subtitle: Text('قيمة الفواتير: ${total.toStringAsFixed(2)} جنيه\nالمدفوع: ${paid.toStringAsFixed(2)} جنيه\nالباقي على المحل: ${remaining.toStringAsFixed(2)} جنيه'))),
          ...docs.map((doc) {
            final d = doc.data();
            return Card(elevation: 0, child: ListTile(
              title: Text('${d['supplier'] ?? 'مورد'} — ${d['branchId'] == 1 ? 'الهرم' : 'أكتوبر'}'),
              subtitle: Text('الإجمالي: ${d['total']} • المدفوع: ${d['paid']} • الباقي: ${d['remaining']} جنيه\n${d['note'] ?? ''}'),
              isThreeLine: true,
              trailing: (d['remaining'] as num? ?? 0) > 0 ? IconButton(tooltip: 'تسجيل دفعة', onPressed: () => _pay(doc), icon: const Icon(Icons.payments)) : const Icon(Icons.check_circle, color: Colors.green),
            ));
          }),
        ]);
      }),
    ));
  }
}

class InventoryScreen extends StatefulWidget {
  final int branch;
  final bool manager;
  const InventoryScreen({super.key, required this.branch, required this.manager});
  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  String get branchName => widget.branch == 1 ? 'افريقيا ستور الهرم' : 'افريقيا ستور اكتوبر';

  Future<void> _chooseReturnProduct() async {
    try {
      final snap = await FirebaseFirestore.instance
          .collection('branches').doc('${widget.branch}')
          .collection('stock').orderBy('name').get();
      if (!mounted) return;
      if (snap.docs.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('لا توجد منتجات مسجلة للاسترجاع')),
        );
        return;
      }
      final selected = await showDialog<QueryDocumentSnapshot<Map<String, dynamic>>>(
        context: context,
        builder: (ctx) => Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: const Text('اختر المنتج المراد استرجاعه'),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView(
                shrinkWrap: true,
                children: snap.docs.map((doc) {
                  final d = doc.data();
                  return ListTile(
                    title: Text((d['name'] ?? 'منتج').toString()),
                    subtitle: Text('الكود: ${d['sku'] ?? '—'} • الرصيد الحالي: ${d['quantity'] ?? 0}'),
                    onTap: () => Navigator.pop(ctx, doc),
                  );
                }).toList(),
              ),
            ),
            actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء'))],
          ),
        ),
      );
      if (selected != null && mounted) await _returnProduct(selected);
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل المنتجات: $e')),
      );
    }
  }

  Future<void> _returnProduct(QueryDocumentSnapshot<Map<String, dynamic>> doc) async {
    final d = doc.data();
    final qty = TextEditingController(text: '1');
    String? error;
    bool busy = false;
    await showDialog<void>(context: context, builder: (dialogContext) => StatefulBuilder(builder: (context, setD) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('استرجاع منتج'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text((d['name'] ?? 'منتج').toString(), style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية المسترجعة', border: OutlineInputBorder())),
          if (error != null) Text(error!, style: const TextStyle(color: Colors.red)),
        ]),
        actions: [
          TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
          FilledButton(onPressed: busy ? null : () async {
            final n = int.tryParse(qty.text.trim());
            if (n == null || n <= 0) { setD(() => error = 'أدخل كمية صحيحة أكبر من صفر'); return; }
            setD(() { busy = true; error = null; });
            try {
              final db = FirebaseFirestore.instance;
              final uid = FirebaseAuth.instance.currentUser!.uid;
              final profile = await db.collection('users').doc(uid).get();
              final cashierName = (profile.data()?['displayName'] ??
                      FirebaseAuth.instance.currentUser?.displayName ??
                      FirebaseAuth.instance.currentUser?.email ??
                      'بائع').toString();
              final stockRef = db.collection('branches').doc('${widget.branch}').collection('stock').doc(doc.id);
              final returnRef = db.collection('branches').doc('${widget.branch}').collection('sales').doc();
              await db.runTransaction((tx) async {
                final snap = await tx.get(stockRef);
                if (!snap.exists) throw StateError('المنتج غير موجود في مخزون الفرع');
                final current = (snap.data()?['quantity'] as num?)?.toInt() ?? 0;
                final price = (d['salePrice'] as num?)?.toDouble() ?? 0;
                tx.update(stockRef, {'quantity': current + n, 'updatedAt': FieldValue.serverTimestamp()});
                tx.set(returnRef, {
                  'branchId': widget.branch, 'type': 'return',
                  'items': [{'productId': doc.id, 'name': d['name'] ?? '', 'sku': d['sku'] ?? '', 'quantity': n, 'unitPrice': price, 'total': price * n}],
                  'total': price * n, 'paymentMethod': 'return',
                  'createdAt': FieldValue.serverTimestamp(),
                  'createdBy': uid,
                  'createdByName': cashierName,
                });
              });
              if (dialogContext.mounted) Navigator.pop(dialogContext);
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل الاسترجاع وإضافة الكمية للمخزون')));
            } catch (e) { setD(() { error = 'تعذر الاسترجاع: $e'; busy = false; }); }
          }, child: Text(busy ? 'جارٍ الحفظ...' : 'تأكيد الاسترجاع')),
        ],
      ),
    )));
    qty.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('branches').doc('${widget.branch}').collection('stock').orderBy('name').snapshots();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [
        Expanded(child: Text('مخزون $branchName', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        if (widget.manager) FilledButton.icon(onPressed: () => showDialog(context: context, builder: (_) => const AddProductDialog()), icon: const Icon(Icons.add), label: const Text('إضافة منتج')),
      ]),
      const SizedBox(height: 10),
      Row(children: [
        Expanded(child: FilledButton.icon(
          onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SaleInvoiceScreen(branch: widget.branch))),
          icon: const Icon(Icons.point_of_sale), label: const Text('بيع / فاتورة'),
        )),
        const SizedBox(width: 8),
        Expanded(child: OutlinedButton.icon(
          onPressed: _chooseReturnProduct,
          icon: const Icon(Icons.assignment_return), label: const Text('استرجاع'),
        )),
      ]),
      const SizedBox(height: 12),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stream, builder: (context, snapshot) {
        if (snapshot.hasError) return _message('تعذر تحميل المخزون: ${snapshot.error}');
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) return _message('لا توجد منتجات في هذا الفرع بعد.');
        return Column(children: docs.map((doc) {
          final d = doc.data();
          return Card(elevation: 0, margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(10), child: Column(children: [
            ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.inventory_2_outlined, color: Color(0xFF234A73)),
              title: Text((d['name'] ?? 'منتج').toString()),
              subtitle: ValueListenableBuilder<int>(valueListenable: OfflineSalesOutbox.revision, builder: (context, _, __) => FutureBuilder<int>(future: OfflineSalesOutbox.reservedQuantity(widget.branch, doc.id), builder: (context, reservedSnap) { final reserved = reservedSnap.data ?? 0; final onHand = (d['quantity'] as num?)?.toInt() ?? 0; return Text('الكود: ${d['sku'] ?? '—'} • الرصيد: ${onHand - reserved} قطعة${reserved > 0 ? ' (منها $reserved بانتظار المزامنة)' : ''}\nسعر البيع: ${d['salePrice'] ?? 0} جنيه'); })), isThreeLine: true),
            Row(children: [
              Expanded(child: FilledButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => SaleInvoiceScreen(branch: widget.branch, initialProductId: doc.id))), icon: const Icon(Icons.add_shopping_cart), label: const Text('بيع'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => _returnProduct(doc), icon: const Icon(Icons.assignment_return), label: const Text('استرجاع'))),
            ]),
          ])));
        }).toList());
      }),
    ]);
  }

  Widget _message(String message) => Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(message, textAlign: TextAlign.center))));
}

class SaleInvoiceScreen extends StatefulWidget {
  final int branch;
  final String? initialProductId;
  const SaleInvoiceScreen({super.key, required this.branch, this.initialProductId});
  @override
  State<SaleInvoiceScreen> createState() => _SaleInvoiceScreenState();
}

class _SaleInvoiceScreenState extends State<SaleInvoiceScreen> {
  final _search = TextEditingController();
  final Map<String, Map<String, dynamic>> _cart = {};
  String _payment = 'cash';
  bool _saving = false;
  String? _error;

  double get _total => _cart.values.fold<double>(0, (sum, item) => sum + ((item['salePrice'] as num).toDouble() * (item['cartQty'] as int)));
  String get _branchName => widget.branch == 1 ? 'الهرم' : 'أكتوبر';

  Future<void> _add(DocumentSnapshot<Map<String, dynamic>> doc) async {
    final d = doc.data() ?? <String, dynamic>{};
    final available = (d['quantity'] as num?)?.toInt() ?? 0;
    final reserved = await OfflineSalesOutbox.reservedQuantity(widget.branch, doc.id);
    if (!mounted) return;
    final existing = _cart[doc.id]?['cartQty'] as int? ?? 0;
    if (available - reserved <= existing) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('الكمية المطلوبة أكبر من المتاح في المخزون')));
      return;
    }
    setState(() {
      _cart[doc.id] = {...d, 'productId': doc.id, 'cartQty': existing + 1, 'reservedQty': reserved};
      _error = null;
    });
  }

  void _changeQty(String id, int delta) {
    final item = _cart[id];
    if (item == null) return;
    final next = (item['cartQty'] as int) + delta;
    final available = (item['quantity'] as num).toInt() - ((item['reservedQty'] as num?)?.toInt() ?? 0);
    if (next <= 0) { setState(() => _cart.remove(id)); return; }
    if (next > available) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لا توجد كمية كافية في المخزون')));
      return;
    }
    setState(() => item['cartQty'] = next);
  }

  Future<void> _checkout() async {
    if (_cart.isEmpty || _saving) return;
    setState(() { _saving = true; _error = null; });
    try {
      final uid = FirebaseAuth.instance.currentUser!.uid;
      final cashierName = (FirebaseAuth.instance.currentUser?.displayName ??
              FirebaseAuth.instance.currentUser?.email ?? 'بائع').toString();
      final entries = _cart.entries.toList();
      final operationId = '${uid}_${DateTime.now().microsecondsSinceEpoch}';
      final payload = <String, dynamic>{
        'operationId': operationId,
        'branchId': widget.branch,
        'createdBy': uid,
        'createdByName': cashierName,
        'paymentMethod': _payment,
        'createdAtLocal': DateTime.now().toUtc().toIso8601String(),
        'items': entries.map((e) => {
          'productId': e.key,
          'name': e.value['name'],
          'sku': e.value['sku'] ?? '',
          'quantity': e.value['cartQty'],
          'unitPrice': (e.value['salePrice'] as num).toDouble(),
        }).toList(),
      };
      var queuedOffline = false;
      try {
        await commitSaleToFirestore(payload);
      } on FirebaseException catch (e) {
        if (['permission-denied', 'failed-precondition', 'invalid-argument'].contains(e.code)) rethrow;
        await OfflineSalesOutbox.enqueue({...payload, 'status': 'pending'});
        queuedOffline = true;
      } on StateError {
        rethrow;
      } catch (_) {
        await OfflineSalesOutbox.enqueue({...payload, 'status': 'pending'});
        queuedOffline = true;
      }
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
        title: Text(queuedOffline ? 'تم حفظ الفاتورة على الجهاز' : 'تم رفع الفاتورة للمدير'),
        content: Text('رقم العملية: $operationId\nعدد الأصناف: ${entries.length}\nإجمالي الفاتورة: ${_total.toStringAsFixed(2)} جنيه\nطريقة الدفع: ${_payment == 'cash' ? 'كاش' : 'إنستاباي'}\n${queuedOffline ? 'ستتم المزامنة تلقائيًا عند عودة الإنترنت. لم تُعتمد الفاتورة مركزيًا بعد.' : 'تم اعتمادها على السيرفر وظهورها في تقارير المدير.'}'),
        actions: [FilledButton(onPressed: () => Navigator.pop(context), child: const Text('تم'))],
      )));
      if (mounted) Navigator.pop(context);
    } catch (e) {
      setState(() { _error = 'لم يتم حفظ الفاتورة: ${e.toString().replaceFirst('Bad state: ', '')}'; _saving = false; });
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.initialProductId != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final snap = await FirebaseFirestore.instance.collection('branches').doc('${widget.branch}').collection('stock').doc(widget.initialProductId).get();
        if (snap.exists && mounted) _add(snap);
      });
    }
  }

  @override
  void dispose() { _search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final stock = FirebaseFirestore.instance.collection('branches').doc('${widget.branch}').collection('stock').where('active', isEqualTo: true).snapshots();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text('فاتورة بيع - فرع $_branchName')),
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(controller: _search, onChanged: (_) => setState(() {}), decoration: const InputDecoration(prefixIcon: Icon(Icons.search), labelText: 'ابحث باسم المنتج أو كود الصنف', border: OutlineInputBorder()))),
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stock, builder: (context, snapshot) {
          if (snapshot.hasError) return Center(child: Text('تعذر تحميل المنتجات: ${snapshot.error}'));
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final q = _search.text.trim().toLowerCase();
          final products = snapshot.data!.docs.where((doc) {
            final d = doc.data();
            return q.isEmpty || (d['name'] ?? '').toString().toLowerCase().contains(q) || (d['sku'] ?? '').toString().toLowerCase().contains(q);
          }).toList();
          return ListView(padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            const Align(alignment: Alignment.centerRight, child: Text('المنتجات المسجلة في البرنامج', style: TextStyle(fontWeight: FontWeight.bold))),
            ...products.map((doc) {
              final d = doc.data();
              return Card(elevation: 0, child: ListTile(
                title: Text((d['name'] ?? 'منتج').toString()),
                subtitle: ValueListenableBuilder<int>(valueListenable: OfflineSalesOutbox.revision, builder: (context, _, __) => FutureBuilder<int>(future: OfflineSalesOutbox.reservedQuantity(widget.branch, doc.id), builder: (context, reservedSnap) { final reserved = reservedSnap.data ?? 0; final available = ((d['quantity'] as num?)?.toInt() ?? 0) - reserved; return Text('الكود: ${d['sku'] ?? '—'} • المتاح: $available${reserved > 0 ? ' (معلق: $reserved)' : ''} • ${d['salePrice'] ?? 0} جنيه'); })),
                trailing: IconButton(onPressed: () => _add(doc), icon: const Icon(Icons.add_circle, color: Color(0xFF234A73)), tooltip: 'إضافة للفاتورة'),
              ));
            }),
          ]);
        })),
        Container(
          decoration: BoxDecoration(color: Theme.of(context).colorScheme.surface, border: Border(top: BorderSide(color: Theme.of(context).dividerColor))),
          padding: const EdgeInsets.all(12),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [const Expanded(child: Text('أصناف الفاتورة', style: TextStyle(fontWeight: FontWeight.bold))), Text('${_cart.length} صنف')]),
            if (_cart.isNotEmpty) ...[
              const SizedBox(height: 6),
              ConstrainedBox(constraints: const BoxConstraints(maxHeight: 150), child: ListView(shrinkWrap: true, children: _cart.entries.map((entry) {
                final item = entry.value;
                final price = (item['salePrice'] as num).toDouble();
                final qty = item['cartQty'] as int;
                return Row(children: [
                  Expanded(child: Text('${item['name']}  × $qty\n${(price * qty).toStringAsFixed(2)} جنيه', maxLines: 2, overflow: TextOverflow.ellipsis)),
                  IconButton(onPressed: () => _changeQty(entry.key, -1), icon: const Icon(Icons.remove_circle_outline)),
                  IconButton(onPressed: () => _changeQty(entry.key, 1), icon: const Icon(Icons.add_circle_outline)),
                ]);
              }).toList())),
            ] else const Padding(padding: EdgeInsets.all(8), child: Text('لم تتم إضافة منتجات للفاتورة بعد')),
            const Divider(),
            Row(children: [const Expanded(child: Text('إجمالي الفاتورة', style: TextStyle(fontWeight: FontWeight.bold))), Text('${_total.toStringAsFixed(2)} جنيه', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18))]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: ChoiceChip(label: const Text('كاش'), selected: _payment == 'cash', onSelected: (_) => setState(() => _payment = 'cash'))),
              const SizedBox(width: 8),
              Expanded(child: ChoiceChip(label: const Text('إنستاباي'), selected: _payment == 'instapay', onSelected: (_) => setState(() => _payment = 'instapay'))),
            ]),
            if (_error != null) Text(_error!, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 8),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _cart.isEmpty || _saving ? null : _checkout, icon: const Icon(Icons.receipt_long), label: Text(_saving ? 'جارٍ حفظ الفاتورة...' : 'تأكيد البيع وحفظ الفاتورة'))),
          ]),
        ),
      ])),
    ));
  }
}
class AddProductDialog extends StatefulWidget {
  const AddProductDialog({super.key});
  @override
  State<AddProductDialog> createState() => _AddProductDialogState();
}

class _AddProductDialogState extends State<AddProductDialog> {
  final _name = TextEditingController();
  final _sku = TextEditingController();
  final _category = TextEditingController();
  final _colors = TextEditingController();
  final _sizes = TextEditingController();
  final _sale = TextEditingController();
  final _cost = TextEditingController();
  final _qty1 = TextEditingController(text: '0');
  final _qty2 = TextEditingController(text: '0');
  bool _busy = false;
  String? _error;

  List<String> _split(String value) => value.split(RegExp(r'[,،\n]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();

  Future<void> _save() async {
    final name = _name.text.trim();
    final sku = _sku.text.trim();
    final sale = double.tryParse(_sale.text.trim());
    final cost = double.tryParse(_cost.text.trim());
    final q1 = int.tryParse(_qty1.text.trim());
    final q2 = int.tryParse(_qty2.text.trim());
    if (name.isEmpty || sku.isEmpty || sale == null || cost == null || q1 == null || q2 == null || sale < 0 || cost < 0 || q1 < 0 || q2 < 0) {
      setState(() => _error = 'أكمل الاسم والكود والأسعار والكميات بأرقام صحيحة غير سالبة.'); return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      final db = FirebaseFirestore.instance;
      final productRef = db.collection('products').doc();
      final normalizedSku = base64Url.encode(utf8.encode(sku.toUpperCase())).replaceAll('=', '');
      final skuRef = db.collection('sku_index').doc(normalizedSku);
      await db.runTransaction((tx) async {
        final existing = await tx.get(skuRef);
        if (existing.exists) throw StateError('كود الصنف مستخدم بالفعل. اختر كودًا مختلفًا.');
        final now = FieldValue.serverTimestamp();
        tx.set(productRef, {
          'name': name, 'sku': sku, 'category': _category.text.trim(),
          'colors': _split(_colors.text), 'sizes': _split(_sizes.text),
          'salePrice': sale, 'active': true, 'createdAt': now,
          'createdBy': FirebaseAuth.instance.currentUser!.uid,
        });
        tx.set(skuRef, {'productId': productRef.id, 'createdAt': now});
        tx.set(productRef.collection('private').doc('cost'), {
          'wholesaleCost': cost, 'updatedAt': now,
          'updatedBy': FirebaseAuth.instance.currentUser!.uid,
        });
        for (final entry in <String, int>{'1': q1, '2': q2}.entries) {
          tx.set(db.collection('branches').doc(entry.key).collection('stock').doc(productRef.id), {
            'productId': productRef.id, 'name': name, 'sku': sku,
            'category': _category.text.trim(), 'salePrice': sale,
            'quantity': entry.value, 'active': true, 'updatedAt': now,
          });
        }
      });
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      setState(() => _error = 'لم يتم الحفظ: ${e.toString().replaceFirst('Bad state: ', '')}');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  void dispose() { for (final c in [_name,_sku,_category,_colors,_sizes,_sale,_cost,_qty1,_qty2]) { c.dispose(); } super.dispose(); }

  Widget _field(TextEditingController c, String label, {TextInputType type = TextInputType.text, String? hint}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: c, keyboardType: type, decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder(), isDense: true)));

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
    title: const Text('إضافة منتج مشترك'),
    content: SizedBox(width: 440, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      _field(_name, 'اسم المنتج *'), _field(_sku, 'كود الصنف / SKU *'), _field(_category, 'القسم أو التصنيف'),
      _field(_colors, 'الألوان', hint: 'أسود، أبيض، كحلي'), _field(_sizes, 'المقاسات', hint: 'S، M، L، XL'),
      _field(_sale, 'سعر البيع *', type: const TextInputType.numberWithOptions(decimal: true)),
      _field(_cost, 'سعر الجملة / التكلفة *', type: const TextInputType.numberWithOptions(decimal: true)),
      const Divider(), const Align(alignment: Alignment.centerRight, child: Text('توزيع الكمية على الفرعين', style: TextStyle(fontWeight: FontWeight.bold))),
      _field(_qty1, 'كمية فرع الهرم *', type: TextInputType.number),
      _field(_qty2, 'كمية فرع أكتوبر *', type: TextInputType.number),
      if (_error != null) Align(alignment: Alignment.centerRight, child: Text(_error!, style: const TextStyle(color: Colors.red))),
    ]))),
    actions: [TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'جارٍ الحفظ...' : 'حفظ المنتج'))],
  ));
}
