# إعداد Firebase داخل مشروع Flutter

تم وضع ملف `google-services.json` في المسار:
`android/app/google-services.json`

بيانات المطابقة التي تم التحقق منها:
- Firebase project: `africa-store-manager`
- Android package: `com.africastore.manager`

## ملاحظة مهمة
الحزمة الأصلية لا تحتوي على ملفات Android/Gradle (مثل `android/settings.gradle` و`android/app/build.gradle`)؛ لذلك إضافة ملف JSON وحدها لا تكفي لتفعيل Firebase أو إنتاج APK.

بعد توليد ملفات Android بواسطة Flutter (`flutter create . --platforms=android` من جذر المشروع)، طبّق إعداد Google Services plugin المتوافق مع إصدار Gradle/Android Gradle Plugin الذي ولّده Flutter، ثم نفّذ:
1. `flutter pub get`
2. `flutter analyze`
3. `flutter run`

وتأكد أن `firebase_core`, `firebase_auth`, و`cloud_firestore` مهيأة في التطبيق قبل الاستخدام.
تم استبدال شاشة الدخول التجريبية بتسجيل دخول Firebase Authentication بالبريد الإلكتروني وكلمة المرور. يجب إنشاء حساب المدير وملف users/{uid} يدوياً من Firebase Console، ثم نشر قواعد Firestore قبل الاختبار. عمليات البيع وباقي العمليات المحاسبية لم تكتمل بعد.
