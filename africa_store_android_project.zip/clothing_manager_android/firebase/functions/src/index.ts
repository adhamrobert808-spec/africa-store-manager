import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { onCall, HttpsError } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();

async function requireManager(uid: string) {
  const snap = await db.doc(`users/${uid}`).get();
  const u = snap.data();
  if (!u || u.active !== true || u.role !== 'manager') {
    throw new HttpsError('permission-denied', 'Manager access required');
  }
  return u;
}

function cleanText(value: unknown, field: string, max = 120): string {
  if (typeof value !== 'string' || value.trim().length === 0 || value.trim().length > max) {
    throw new HttpsError('invalid-argument', `${field} is required (max ${max} characters)`);
  }
  return value.trim();
}

function cleanList(value: unknown, field: string): string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 40 || value.some(v => typeof v !== 'string' || v.trim().length === 0 || v.trim().length > 40)) {
    throw new HttpsError('invalid-argument', `${field} must be a list of up to 40 text values`);
  }
  return [...new Set(value.map(v => (v as string).trim()))];
}

function nonNegativeNumber(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) {
    throw new HttpsError('invalid-argument', `${field} must be a non-negative number`);
  }
  return value;
}

function nonNegativeInteger(value: unknown, field: string): number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new HttpsError('invalid-argument', `${field} must be a non-negative integer`);
  }
  return value;
}

// One shared product definition, two independently controlled branch stock records.
// All writes run on the trusted server; clients cannot write stock or cost documents directly.
export const addSharedProduct = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  await requireManager(request.auth.uid);

  const data = request.data ?? {};
  const name = cleanText(data.name, 'name');
  const sku = cleanText(data.sku, 'sku', 60);
  const category = typeof data.category === 'string' ? data.category.trim().slice(0, 80) : '';
  const colors = cleanList(data.colors, 'colors');
  const sizes = cleanList(data.sizes, 'sizes');
  const salePrice = nonNegativeNumber(data.salePrice, 'salePrice');
  const wholesaleCost = nonNegativeNumber(data.wholesaleCost, 'wholesaleCost');
  const quantities = data.branchQuantities;
  if (!quantities || typeof quantities !== 'object') {
    throw new HttpsError('invalid-argument', 'branchQuantities for branches 1 and 2 are required');
  }
  const qty1 = nonNegativeInteger(quantities['1'], 'branch 1 quantity');
  const qty2 = nonNegativeInteger(quantities['2'], 'branch 2 quantity');

  const normalizedSku = sku.toUpperCase().replace(/[^A-Z0-9_-]/g, '_');
  const skuRef = db.doc(`sku_index/${normalizedSku}`);
  const productRef = db.collection('products').doc();
  const now = FieldValue.serverTimestamp();

  await db.runTransaction(async (tx) => {
    const existingSku = await tx.get(skuRef);
    if (existingSku.exists) throw new HttpsError('already-exists', 'هذا الكود مستخدم بالفعل لمنتج آخر');

    tx.create(productRef, {
      name, sku, category, colors, sizes, salePrice,
      active: true, createdAt: now, createdBy: request.auth!.uid,
    });
    tx.create(skuRef, { productId: productRef.id, createdAt: now });
    tx.create(db.doc(`products/${productRef.id}/private/cost`), {
      wholesaleCost, updatedAt: now, updatedBy: request.auth!.uid,
    });

    for (const [branchId, quantity] of [['1', qty1], ['2', qty2]] as const) {
      tx.create(db.doc(`branches/${branchId}/stock/${productRef.id}`), {
        productId: productRef.id, name, sku, category, salePrice,
        quantity, active: true, updatedAt: now,
      });
    }
  });

  return { ok: true, productId: productRef.id, branchQuantities: { '1': qty1, '2': qty2 } };
});

// Manager-only user provisioning. Create the Firebase Auth account in a trusted admin flow first.
export const setSellerProfile = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first');
  await requireManager(request.auth.uid);
  const { uid, branchId, displayName } = request.data ?? {};
  if (typeof uid !== 'string' || ![1, 2].includes(branchId) || typeof displayName !== 'string') {
    throw new HttpsError('invalid-argument', 'uid, displayName and branchId (1 or 2) are required');
  }
  await db.doc(`users/${uid}`).set({ role: 'seller', branchId, displayName, active: true, createdAt: FieldValue.serverTimestamp() });
  return { ok: true };
});
