# Firebase deployment notes

The current Flutter source uses Firebase Authentication and Firestore. Product creation is a manager-only Firestore transaction (no Cloud Functions deployment is required for this initial product workflow). Firestore rules block seller writes and protect wholesale cost.

Before testing:
1. Enable Email/Password in Firebase Authentication.
2. Create the manager authentication user in Firebase Console.
3. Create `users/{uid}` in Firestore using that Auth UID, with `role: "manager"`, `active: true`, and `displayName: "Store Manager"`. This profile must be created from the Firebase Console or trusted Admin SDK, not the app.
4. Deploy the repository `firestore.rules` to the same Firebase project.
5. Generate the missing Android Gradle project with Flutter, then configure the Google Services plugin. See `ANDROID_FIREBASE_SETUP.md`.

Product data layout:
- `products/{productId}`: shared product name, SKU, category, colors, sizes, sale price, active flag.
- `products/{productId}/private/cost`: manager-only wholesale cost.
- `branches/1/stock/{productId}`: independent Al-Haram branch quantity.
- `branches/2/stock/{productId}`: independent October branch quantity.
- `sku_index/{encodedSku}`: manager-only duplicate-SKU guard.

The remaining sales, purchases, transfers, inventory counts, refunds, and reporting workflows are not production-ready. They must use validated server-side transactions before commercial use.
