import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const AfricaStoreApp());
}

class AfricaStoreApp extends StatelessWidget {
  const AfricaStoreApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'مدير افريقيا ستور',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF234A73)),
          scaffoldBackgroundColor: const Color(0xFFF5F7FA),
          fontFamily: 'Arial',
        ),
        home: const LoginScreen(),
      );
}

class StoreSession {
  final String uid;
  final String role;
  final int? branchId;
  final String displayName;
  const StoreSession({required this.uid, required this.role, required this.displayName, this.branchId});
  bool get isManager => role == 'manager';
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _busy = false;
  bool _hide = true;
  String? _error;

  Future<void> _login() async {
    setState(() { _busy = true; _error = null; });
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: _email.text.trim(), password: _password.text,
      );
      final uid = credential.user!.uid;
      final profile = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final data = profile.data();
      if (!profile.exists || data?['active'] != true || !['manager', 'seller'].contains(data?['role'])) {
        await FirebaseAuth.instance.signOut();
        throw Exception('الحساب غير مفعل. راجع مدير النظام لإعداد الصلاحيات.');
      }
      final role = data!['role'] as String;
      final branchId = data['branchId'] is int ? data['branchId'] as int : null;
      if (role == 'seller' && branchId != 1 && branchId != 2) {
        await FirebaseAuth.instance.signOut();
        throw Exception('لم يتم ربط حساب البائع بفرع صحيح.');
      }
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (_) => HomeScreen(session: StoreSession(
          uid: uid, role: role, branchId: branchId,
          displayName: (data['displayName'] ?? _email.text.trim()).toString(),
        )),
      ));
    } on FirebaseAuthException catch (e) {
      setState(() => _error = e.code == 'user-not-found' || e.code == 'wrong-password' || e.code == 'invalid-credential'
          ? 'البريد الإلكتروني أو كلمة المرور غير صحيحة.' : 'تعذر تسجيل الدخول: ${e.message ?? e.code}');
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() { _email.dispose(); _password.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: Scaffold(
    body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440), child: Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Icon(Icons.storefront, size: 54, color: Color(0xFF234A73)),
          const SizedBox(height: 12), const Text('مدير افريقيا ستور', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6), const Text('تسجيل الدخول الآمن', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54)),
          const SizedBox(height: 24),
          TextField(controller: _email, keyboardType: TextInputType.emailAddress, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'البريد الإلكتروني', prefixIcon: Icon(Icons.email_outlined), border: OutlineInputBorder())),
          const SizedBox(height: 14),
          TextField(controller: _password, obscureText: _hide, decoration: InputDecoration(labelText: 'كلمة المرور', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => _hide = !_hide)), border: const OutlineInputBorder())),
          if (_error != null) ...[const SizedBox(height: 12), Text(_error!, style: const TextStyle(color: Colors.red), textAlign: TextAlign.center)],
          const SizedBox(height: 20), FilledButton.icon(onPressed: _busy ? null : _login, icon: const Icon(Icons.login), label: Padding(padding: const EdgeInsets.all(12), child: Text(_busy ? 'جارٍ التحقق...' : 'دخول'))),
          const SizedBox(height: 12), const Text('يتطلب حساب Firebase مفعّلاً وصلاحية محددة من مدير النظام.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: Colors.black54)),
        ],
      ))))))),
  ));
}

class HomeScreen extends StatefulWidget {
  final StoreSession session;
  const HomeScreen({super.key, required this.session});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    final pages = s.isManager
        ? <Widget>[const DashboardScreen(), const InventoryScreen(branch: 1, manager: true), const InventoryScreen(branch: 2, manager: true)]
        : <Widget>[InventoryScreen(branch: s.branchId!, manager: false)];
    final titles = s.isManager ? ['لوحة المدير', 'مخزون افريقيا ستور الهرم', 'مخزون افريقيا ستور اكتوبر'] : ['مخزون ${s.branchId == 1 ? 'الهرم' : 'اكتوبر'}'];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(titles[_index]), actions: [IconButton(tooltip: 'خروج', onPressed: () async { await FirebaseAuth.instance.signOut(); if (context.mounted) Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const LoginScreen())); }, icon: const Icon(Icons.logout))]),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(selectedIndex: _index, onDestinationSelected: (v) => setState(() => _index = v), destinations: s.isManager
          ? const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'الرئيسية'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 1'), NavigationDestination(icon: Icon(Icons.store), label: 'فرع 2')]
          : const [NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'المخزون')]),
    ));
  }
}

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    Text('إدارة أفريقيا ستور', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    SizedBox(height: 10),
    Card(elevation: 0, child: ListTile(leading: Icon(Icons.inventory_2_outlined), title: Text('كتالوج منتجات موحد'), subtitle: Text('تعريف المنتج مرة واحدة وتوزيع الرصيد بين الهرم وأكتوبر.'))),
    Card(elevation: 0, child: ListTile(leading: Icon(Icons.store), title: Text('مخزون مستقل لكل فرع'), subtitle: Text('كل فرع يحتفظ بكميته الخاصة من المنتج المشترك.'))),
    Card(elevation: 0, child: ListTile(leading: Icon(Icons.security), title: Text('صلاحيات محمية'), subtitle: Text('تسجيل الدخول والصلاحيات من Firebase Authentication وFirestore.'))),
  ]);
}

class InventoryScreen extends StatelessWidget {
  final int branch;
  final bool manager;
  const InventoryScreen({super.key, required this.branch, required this.manager});
  String get branchName => branch == 1 ? 'افريقيا ستور الهرم' : 'افريقيا ستور اكتوبر';

  @override
  Widget build(BuildContext context) {
    final stockStream = FirebaseFirestore.instance.collection('branches').doc('$branch').collection('stock').orderBy('name').snapshots();
    return ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [Expanded(child: Text('مخزون $branchName', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))), if (manager) FilledButton.icon(onPressed: () => showDialog(context: context, builder: (_) => AddProductDialog()), icon: const Icon(Icons.add), label: const Text('إضافة منتج'))]),
      const SizedBox(height: 12),
      StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stockStream, builder: (context, snapshot) {
        if (snapshot.hasError) return _message('تعذر تحميل المخزون: ${snapshot.error}');
        if (snapshot.connectionState == ConnectionState.waiting) return const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()));
        final docs = snapshot.data?.docs ?? [];
        if (docs.isEmpty) return _message('لا توجد منتجات في هذا الفرع بعد. أضف منتجًا من حساب المدير.');
        return Column(children: docs.map((doc) {
          final d = doc.data();
          return Card(elevation: 0, child: ListTile(
            leading: const Icon(Icons.inventory_2_outlined, color: Color(0xFF234A73)),
            title: Text((d['name'] ?? 'منتج').toString()),
            subtitle: Text('الكود: ${d['sku'] ?? '—'}  •  ${d['category'] ?? 'بدون تصنيف'}\nالرصيد: ${d['quantity'] ?? 0} قطعة  •  سعر البيع: ${d['salePrice'] ?? 0}'),
            isThreeLine: true,
          ));
        }).toList());
      }),
    ]);
  }

  Widget _message(String message) => Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(message, textAlign: TextAlign.center))));
}

class AddProductDialog extends StatefulWidget {
  const AddProductDialog({super.key});
  @override
  State<AddProductDialog> createState() => _AddProductDialogState();
}

class _AddProductDialogState extends State<AddProductDialog> {
  final _name = TextEditingController();
  final _sku = TextEditingController();
  final _category = TextEditingController();
  final _colors = TextEditingController();
  final _sizes = TextEditingController();
  final _sale = TextEditingController();
  final _cost = TextEditingController();
  final _qty1 = TextEditingController(text: '0');
  final _qty2 = TextEditingController(text: '0');
  bool _busy = false;
  String? _error;

  List<String> _split(String value) => value.split(RegExp(r'[,،\n]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toSet().toList();

  Future<void> _save() async {
    final name = _name.text.trim();
    final sku = _sku.text.trim();
    final sale = double.tryParse(_sale.text.trim());
    final cost = double.tryParse(_cost.text.trim());
    final q1 = int.tryParse(_qty1.text.trim());
    final q2 = int.tryParse(_qty2.text.trim());
    if (name.isEmpty || sku.isEmpty || sale == null || cost == null || q1 == null || q2 == null || sale < 0 || cost < 0 || q1 < 0 || q2 < 0) {
      setState(() => _error = 'أكمل الاسم والكود والأسعار والكميات بأرقام صحيحة غير سالبة.'); return;
    }
    setState(() { _busy = true; _error = null; });
    try {
      final db = FirebaseFirestore.instance;
      final productRef = db.collection('products').doc();
      final normalizedSku = base64Url.encode(utf8.encode(sku.toUpperCase())).replaceAll('=', '');
      final skuRef = db.collection('sku_index').doc(normalizedSku);
      await db.runTransaction((tx) async {
        final existing = await tx.get(skuRef);
        if (existing.exists) throw StateError('كود الصنف مستخدم بالفعل. اختر كودًا مختلفًا.');
        final now = FieldValue.serverTimestamp();
        tx.set(productRef, {
          'name': name, 'sku': sku, 'category': _category.text.trim(),
          'colors': _split(_colors.text), 'sizes': _split(_sizes.text),
          'salePrice': sale, 'active': true, 'createdAt': now,
          'createdBy': FirebaseAuth.instance.currentUser!.uid,
        });
        tx.set(skuRef, {'productId': productRef.id, 'createdAt': now});
        tx.set(productRef.collection('private').doc('cost'), {
          'wholesaleCost': cost, 'updatedAt': now,
          'updatedBy': FirebaseAuth.instance.currentUser!.uid,
        });
        for (final entry in <String, int>{'1': q1, '2': q2}.entries) {
          tx.set(db.collection('branches').doc(entry.key).collection('stock').doc(productRef.id), {
            'productId': productRef.id, 'name': name, 'sku': sku,
            'category': _category.text.trim(), 'salePrice': sale,
            'quantity': entry.value, 'active': true, 'updatedAt': now,
          });
        }
      });
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      setState(() => _error = 'لم يتم الحفظ: ${e.toString().replaceFirst('Bad state: ', '')}');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  void dispose() { for (final c in [_name,_sku,_category,_colors,_sizes,_sale,_cost,_qty1,_qty2]) { c.dispose(); } super.dispose(); }

  Widget _field(TextEditingController c, String label, {TextInputType type = TextInputType.text, String? hint}) => Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(controller: c, keyboardType: type, decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder(), isDense: true)));

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
    title: const Text('إضافة منتج مشترك'),
    content: SizedBox(width: 440, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
      _field(_name, 'اسم المنتج *'), _field(_sku, 'كود الصنف / SKU *'), _field(_category, 'القسم أو التصنيف'),
      _field(_colors, 'الألوان', hint: 'أسود، أبيض، كحلي'), _field(_sizes, 'المقاسات', hint: 'S، M، L، XL'),
      _field(_sale, 'سعر البيع *', type: const TextInputType.numberWithOptions(decimal: true)),
      _field(_cost, 'سعر الجملة / التكلفة *', type: const TextInputType.numberWithOptions(decimal: true)),
      const Divider(), const Align(alignment: Alignment.centerRight, child: Text('توزيع الكمية على الفرعين', style: TextStyle(fontWeight: FontWeight.bold))),
      _field(_qty1, 'كمية فرع الهرم *', type: TextInputType.number),
      _field(_qty2, 'كمية فرع أكتوبر *', type: TextInputType.number),
      if (_error != null) Align(alignment: Alignment.centerRight, child: Text(_error!, style: const TextStyle(color: Colors.red))),
    ]))),
    actions: [TextButton(onPressed: _busy ? null : () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? 'جارٍ الحفظ...' : 'حفظ المنتج'))],
  ));
}
