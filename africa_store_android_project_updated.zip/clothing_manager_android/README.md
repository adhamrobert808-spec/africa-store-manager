# مدير افريقيا ستور — مشروع Android

تطبيق Flutter عربي لإدارة فرعين:
- افريقيا ستور الهرم (`branchId = 1`)
- افريقيا ستور اكتوبر (`branchId = 2`)

## ما تم تنفيذه في هذه النسخة المصدرية
- تسجيل دخول فعلي عبر Firebase Authentication (بريد إلكتروني وكلمة مرور)، مع قراءة دور المستخدم من `users/{uid}`.
- كتالوج منتجات موحد: تعريف المنتج مرة واحدة في `products/{productId}`.
- أرصدة منفصلة للفرعين في `branches/{branchId}/stock/{productId}`.
- شاشة إضافة منتج تشمل الاسم والكود والقسم والألوان والمقاسات وسعر البيع والتكلفة وكمية كل فرع.
- تخزين تكلفة الجملة في مستند خاص `products/{productId}/private/cost` لا يستطيع البائع قراءته.
- حماية الكتابة بقواعد Firestore: المدير فقط يضيف المنتجات ويعدل أرصدة الفروع.
- عرض المخزون الفعلي للفرع في شاشة المخزون.

**حدود النسخة الحالية:** الكمية المسجلة مستقلة لكل فرع على مستوى المنتج إجمالاً. الألوان والمقاسات تُحفظ كخيارات للمنتج، لكن توزيع الكميات على كل تركيبة لون/مقاس، والمبيعات والمشتريات والتحويلات والجرد والفواتير PDF، ما زالت مراحل لاحقة. لا تستخدمها بعد كنظام محاسبي إنتاجي.

## مشروع Firebase المرتبط
ملف `android/app/google-services.json` الموجود في الحزمة يشير إلى:
- Firebase project: `africa-store-manager`
- Android package: `com.africastore.manager`

ملف JSON وحده لا يكفي. الحزمة الأصلية لا تتضمن مجلد Android/Gradle؛ يجب توليده محلياً باستخدام Flutter ثم إكمال Google Services plugin وفق إصدار Gradle الذي يولده Flutter.

## إعداد أول مرة — مطلوب قبل تسجيل الدخول
1. في Firebase Console للمشروع `africa-store-manager` فعّل Authentication ثم Email/Password.
2. من Authentication أنشئ مستخدم المدير بالبريد وكلمة مرور تختارها أنت. لا ترسل كلمة المرور في المحادثة.
3. انسخ UID الخاص بالمستخدم.
4. من Firestore أنشئ مجموعة `users` ثم مستنداً يكون معرّفه UID نفسه، وأضف الحقول:
   - `role` = `manager` (String)
   - `active` = `true` (Boolean)
   - `displayName` = اسم المدير (String)
5. انشر قواعد `firestore.rules` على Firestore. من جذر المشروع يمكن استخدام Firebase CLI: `firebase deploy --only firestore:rules` بعد تسجيل الدخول واختيار المشروع الصحيح.
6. لا تنشئ مستند المستخدم من التطبيق؛ قواعد الأمان تمنع ذلك عمداً.

## تشغيل Android محلياً
1. ثبّت Flutter SDK وAndroid Studio.
2. افتح مجلد `clothing_manager_android`.
3. نفّذ `flutter create . --platforms=android` لتوليد ملفات Android الناقصة، مع الحفاظ على `applicationId` = `com.africastore.manager`.
4. أضف Google Services plugin إلى Gradle وفق تعليمات Firebase الحالية وإصدار Gradle الذي تم توليده.
5. نفّذ `flutter pub get` ثم `flutter analyze` ثم `flutter run`.
6. بعد التأكد من نجاح الاختبارات فقط، أنشئ APK باستخدام `flutter build apk --release`.

## ملاحظات أمنية وتشغيلية
- شاشة الدخول لم تعد تسمح باختيار الدور يدوياً؛ الدور والفرع يُقرآن من ملف المستخدم في Firestore.
- لا تضع service-account JSON أو كلمات مرور داخل التطبيق أو GitHub.
- لا تعتبر المشروع إنتاجياً قبل استكمال عمليات البيع الذرية، المرتجعات، التحويلات، الجرد، النسخ الاحتياطي، واختبارات الصلاحيات على جهازين.
